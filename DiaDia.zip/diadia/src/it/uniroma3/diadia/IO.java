package it.uniroma3.diadia;


public interface IO {
	
	public void showMsg(String messaggio);
	
	public  String readLine();
}
